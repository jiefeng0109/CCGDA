# import os
# import torch
# import logging
# import argparse
#
# from tqdm import tqdm
# from datetime import datetime
#
# from configs import CFG
# from metric import Metric
# from models import build_model
# from datas import build_dataset, build_dataloader
#
#
import os
import torch
import random
import logging
import argparse
import numpy as np
import torch.distributed as dist
import torch.multiprocessing as mp

from tqdm import tqdm
from PIL import Image
from datetime import datetime
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from apex.parallel import DistributedDataParallel
from torch.utils.data.distributed import DistributedSampler

from configs import CFG
from auxiliary_func import *
from models import build_model
from criterions import build_criterion
from datas import build_dataset, build_dataloader
from ptflops import get_model_complexity_info
from thop import profile
from thop import clever_format


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('config',
                        type=str,
                        default='configs/houston/plotfig.yaml',
                        help='config file')
    parser.add_argument('--checkpoint',
                        type=str,
                        default='runs/houston/CCGDA/best_0.pth',
                        help='checkpoint file')
    parser.add_argument('--path',
                        type=str,
                        default=os.path.join('../../runs', datetime.now().strftime('%Y%m%d-%H%M%S-train')),
                        help='path for experiment output files')
    parser.add_argument('--no-validate',
                        action='store_true',
                        help='whether not to validate in the training process')
    parser.add_argument('-n',
                        '--nodes',
                        type=int,
                        default=1,
                        help='number of nodes / machines')
    parser.add_argument('-g',
                        '--gpus',
                        type=int,
                        default=1,
                        help='number of GPUs per node / machine')
    parser.add_argument('-r',
                        '--rank-node',
                        type=int,
                        default=0,
                        help='ranking of the current node / machine')
    parser.add_argument('--backend',
                        type=str,
                        default='gloo',
                        help='backend for PyTorch DDP')
    parser.add_argument('--master-ip',
                        type=str,
                        default='localhost',
                        help='network IP of the master node / machine')
    parser.add_argument('--master-port',
                        type=str,
                        default='1999',
                        help='network port of the master process on the master node / machine')
    parser.add_argument('--seed',
                        type=int,
                        default=30,
                        help='random seed')
    parser.add_argument('--sample-number',
                        type=int,
                        default=1000,
                        help='random seed')
    parser.add_argument('--opt-level',
                        type=str,
                        default='O2',
                        help='optimization level for nvidia/apex')
    args = parser.parse_args()
    # number of GPUs totally, which equals to the number of processes
    args.world_size = args.nodes * args.gpus
    return args


def worker(rank_gpu, args):
    # create experiment output path if not exists
    if not os.path.exists(args.path):
        os.makedirs(args.path, exist_ok=True)

    # merge config with config file
    CFG.merge_from_file(args.config)

    assert CFG.EPOCHS % args.world_size == 0, 'cannot apportion epoch to gpus averagely'
    # log to file and stdout
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s: %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(args.path, 'test.log')),
            logging.StreamHandler(),
        ])

    # rank of global worker
    rank_process = args.gpus * args.rank_node + rank_gpu
    dist.init_process_group(backend=args.backend,
                            init_method=f'tcp://{args.master_ip}:{args.master_port}',
                            world_size=args.world_size,
                       rank=rank_process)
    # number of workers
    logging.info('train on {} of {} processes'.format(rank_process + 1, dist.get_world_size()))

    # use device cuda:n in the process #n
    torch.cuda.set_device(rank_gpu)
    device = torch.device('cuda', rank_gpu)

    # set random seed
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)


    NUM_CHANNELS = 48
    NUM_CLASSES = 7
    # logging.info("Number of class: {}".format(NUM_CLASSES))
    # build data sampler
    # train_sampler = DistributedSampler(train_dataset, shuffle=True)
    # train_sampler = ImbalancedDatasetSampler(train_dataset, labels=train_dataset.get_labels())
    # source_sampler = DistributedSampler(source_dataset, shuffle=False)
    # val_sampler = DistributedSampler(val_dataset, shuffle=False)
    # # test_sampler = DistributedSampler(test_dataset, shuffle=True)
    # # test_sampler = ImbalancedDatasetSampler(test_dataset, labels=test_dataset.get_labels())
    # print('GT:', type(val_dataset.get_labels()))
    # print('shape of GT:', val_dataset.get_labels().shape)
    # # build data loader
    # # train_dataloader = build_dataloader(train_dataset, sampler=train_sampler)
    # source_dataloader = build_dataloader(source_dataset, sampler=source_sampler)
    # val_dataloader = build_dataloader(val_dataset, sampler=val_sampler)
    # test_dataloader = build_dataloader(test_dataset, sampler=test_sampler)

    # val_criterion = build_criterion(CFG.CRITERION.ITEMS4, CFG.CRITERION.WEIGHTS4)
    # val_criterion.to(device)

    # build model TODO: notice here
    G, D, C = build_model(NUM_CHANNELS, NUM_CLASSES)
    G.to(device)
    D.to(device)
    C.to(device)

    # DDP
    G = DistributedDataParallel(G)
    D = DistributedDataParallel(D)
    C = DistributedDataParallel(C)

    epoch = 0

    # load checkpoint if specified
    if args.checkpoint is not None:
        if not os.path.isfile(args.checkpoint):
            raise RuntimeError('checkpoint {} not found'.format(args.checkpoint))
        checkpoint = torch.load(args.checkpoint)
        G.load_state_dict(checkpoint['G']['state_dict'])
        D.load_state_dict(checkpoint['D']['state_dict'])
        C.load_state_dict(checkpoint['C']['state_dict'])
        # epoch = checkpoint['optimizer']['epoch']
        # iteration = checkpoint['optimizer']['iteration']
        best_OA = checkpoint['metric']['OA']
        # best_epoch = checkpoint['optimizer']['best_epoch']
        logging.info('load checkpoint {} with OA={:.4f}, epoch={}'.format(args.checkpoint, best_OA, epoch))

    # ptflops不支持多输入模型
    # macs_g, params_g = get_model_complexity_info(G, ((1, 48), (1, 7), (1, 48, 27, 27)), as_strings=True, print_per_layer_stat=False,
    #                                              verbose=True)
    # print('{:<30}  {:<8}'.format('Computational complexity G: ', macs_g))
    # print('{:<30}  {:<8}'.format('Number of parameters G: ', params_g))

    macs_d, params_d = get_model_complexity_info(D, (48, 27, 27), as_strings=True, print_per_layer_stat=False,
                                                 verbose=True)
    print('{:<30}  {:<8}'.format('Computational complexity D: ', macs_d))
    print('{:<30}  {:<8}'.format('Number of parameters D: ', params_d))

    macs_c, params_c = get_model_complexity_info(C, (48, 27, 27), as_strings=True, print_per_layer_stat=False,
                                                 verbose=True)
    print('{:<30}  {:<8}'.format('Computational complexity C: ', macs_c))
    print('{:<30}  {:<8}'.format('Number of parameters C: ', params_c))

    z = torch.randn(1, 48).to(device)
    y = torch.randn(1, 7).to(device)
    x = torch.randn(1, 48, 27, 27).to(device)

    macs_g, params_g = profile(G, inputs=(z, y, x), verbose=False)
    print(f"macs = {macs_g / 1e9}G")
    print(f"params = {params_g / 1e6}M")

    macs_d, params_d = profile(D, inputs=(x,), verbose=False)
    print(f"macs = {macs_d / 1e9}G")
    print(f"params = {params_d / 1e6}M")

    macs_c, params_c = profile(C, inputs=(x,), verbose=False)
    print(f"macs = {macs_c / 1e9}G")
    print(f"params = {params_c / 1e6}M")

    # train - validation loop

    # validate
    # G.eval()  # set model to evaluation mode
    # D.eval()  # set model to evaluation mode
    # C.eval()  # set model to evaluation mode
    # # TODO attention:如果 retain graph = true 此处不能用eval() 否则计算图会被free掉 导致模型失效
    # metric.reset()  # reset metric

    # val_loss = 0.
    # features_s, features_t = [], []
    # labels_s, labels_t = [], []
    # with torch.no_grad():  # disable gradient back-propagation
    #     val_bar = tqdm(val_dataloader, desc='validating', ascii=True)
    #     for x_t, label, index in val_bar:
    #         x_t, label = x_t.to(device), label.to(device)
    #         f_t, y_t = C(x_t)
    #
    #         loss = val_criterion(y_t, label)
    #         val_loss += loss.item()
    #
    #         pred = y_t.argmax(axis=1)
    #         # print(f_t.data.cpu().numpy().shape)
    #         features_t.append(f_t.data.cpu().numpy())
    #         labels_t.append(label.data.cpu().numpy())
    #         val_dataset.update_pred(index.cpu(), pred.cpu())
    #         val_dataset.update_gtmap(index.cpu(), label.cpu())
    #         oa, aa, kappa, per_class_acc = get_criteria(pred.cpu().numpy(), label.cpu().numpy(), NUM_CLASSES)
    #
    #         val_bar.set_postfix({
    #             'epoch': epoch,
    #             'loss': f'{loss.item():.4f}',
    #             'OA': f'{oa:.4f}',
    #             'AA': f'{aa:.4f}',
    #             'Kappa': f'{kappa:.4f}'
    #         })
    #
    #     source_bar = tqdm(source_dataloader, desc='inferring-s', ascii=True)
    #     for x_s, label, index in source_bar:
    #         x_s, label = x_s.to(device), label.to(device)
    #         f_s, _ = C(x_s)
    #         # print(f_s.data.cpu().numpy().shape)
    #         features_s.append(f_s.data.cpu().numpy())
    #         labels_s.append(label.data.cpu().numpy())

    # labels_s, labels_t = np.concatenate(labels_s), np.concatenate(labels_t)
    # features_s, features_t = np.concatenate(features_s), np.concatenate(features_t)





def main():
    # parse command line arguments
    args = parse_args()

    # multi processes, each process runs worker(i,args) i=range(nprocs)
    # total processes = world size = nprocs*nodes
    mp.spawn(worker, args=(args,), nprocs=args.gpus)


if __name__ == '__main__':
    main()



# def parse_args():
#     parser = argparse.ArgumentParser()
#     parser.add_argument('config',
#                         type=str,
#                         help='config file')
#     parser.add_argument('checkpoint',
#                         type=str,
#                         help='checkpoint file')
#     parser.add_argument('--device',
#                         type=str,
#                         default='cuda:0',
#                         help='device for test')
#     parser.add_argument('--path',
#                         type=str,
#                         default=os.path.join('runs', datetime.now().strftime('%Y%m%d-%H%M%S-test')),
#                         help='path for experiment output files')
#     args = parser.parse_args()
#     return args
#
#
# def main():
#     # parse command line arguments
#     args = parse_args()
#     if not os.path.exists(args.path):
#         os.makedirs(args.path, exist_ok=True)
#
#     # merge config with config file
#     CFG.merge_from_file(args.config)
#
#     # dump config
#     with open(os.path.join(args.path, 'config.yaml'), 'w') as f:
#         f.write(CFG.dump())
#
#     logging.basicConfig(
#         level=logging.INFO,
#         format='%(asctime)s: %(message)s',
#         handlers=[
#             logging.FileHandler(os.path.join(args.path, 'test.log')),
#             logging.StreamHandler(),
#         ])
#
#     # build dataset
#     test_dataset = build_dataset('test')
#     NUM_CHANNELS = test_dataset.num_channels
#     NUM_CLASSES = test_dataset.num_classes
#     # build data loader
#     test_dataloader = build_dataloader(test_dataset)
#     # build model
#     model = build_model(NUM_CHANNELS, NUM_CLASSES)
#     model.to(args.device)
#     # build metric
#     metric = Metric(NUM_CLASSES)
#
#     # load checkpoint
#     if not os.path.isfile(args.checkpoint):
#         raise RuntimeError('checkpoint {} not found'.format(args.checkpoint))
#     checkpoint = torch.load(args.checkpoint)
#     # delete module saved in train
#     model.load_state_dict(({k.replace('module.', ''): v for k, v in checkpoint['model']['state_dict'].items()}))
#     best_PA = checkpoint['metric']['PA']
#     logging.info('load checkpoint {} with PA={:.3f}'.format(args.checkpoint, best_PA))
#
#     # test
#     model.eval()  # set model to evaluation mode
#     metric.reset()  # reset metric
#     test_bar = tqdm(test_dataloader, desc='testing', ascii=True)
#     with torch.no_grad():  # disable gradient back-propagation
#         for batch, (x, label) in enumerate(test_bar):
#             # change DoubleTensor x to FloatTensor
#             x, label = x.float().to(args.device), label.to(args.device)
#             _, y = model(x)
#
#             if NUM_CLASSES > 2:
#                 pred = y.data.cpu().numpy().argmax(axis=1)
#             else:
#                 pred = (y.data.cpu().numpy() > 0.5).squeeze(1)
#             label = label.data.cpu().numpy()
#             metric.add(pred, label)
#     PA, mPA, Ps, Rs, F1S = metric.PA(), metric.mPA(), metric.Ps(), metric.Rs(), metric.F1s()
#     logging.info('test | PA={:.3f} mPA={:.3f} worst={:.3f}'.format(PA, mPA, min(mPA)))
#     for c in range(NUM_CLASSES):
#         logging.info(
#             'test | class={}-{} P={:.3f} R={:.3f} F1={:.3f}'.format(c, test_dataset.names[c], Ps[c], Rs[c], F1S[c]))
#
#
# if __name__ == '__main__':
#     main()


