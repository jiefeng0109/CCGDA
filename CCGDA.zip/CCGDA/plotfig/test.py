import os
import torch
import random
import logging
import argparse
import numpy as np
import torch.distributed as dist
import torch.multiprocessing as mp

from tqdm import tqdm
from PIL import Image
from datetime import datetime
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
from apex.parallel import DistributedDataParallel
from torch.utils.data.distributed import DistributedSampler

from configs import CFG
from auxiliary_func import *
from models import build_model
from criterions import build_criterion
from datas import build_dataset, build_dataloader
from plotter import plot_label


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('config',
                        type=str,
                        help='config file')
    parser.add_argument('--checkpoint',
                        type=str,
                        default=None,
                        help='checkpoint file')
    parser.add_argument('--path',
                        type=str,
                        default=os.path.join('../../runs', datetime.now().strftime('%Y%m%d-%H%M%S-train')),
                        help='path for experiment output files')
    parser.add_argument('--no-validate',
                        action='store_true',
                        help='whether not to validate in the training process')
    parser.add_argument('-n',
                        '--nodes',
                        type=int,
                        default=1,
                        help='number of nodes / machines')
    parser.add_argument('-g',
                        '--gpus',
                        type=int,
                        default=1,
                        help='number of GPUs per node / machine')
    parser.add_argument('-r',
                        '--rank-node',
                        type=int,
                        default=0,
                        help='ranking of the current node / machine')
    parser.add_argument('--backend',
                        type=str,
                        default='nccl',
                        help='backend for PyTorch DDP')
    parser.add_argument('--master-ip',
                        type=str,
                        default='localhost',
                        help='network IP of the master node / machine')
    parser.add_argument('--master-port',
                        type=str,
                        default='8888',
                        help='network port of the master process on the master node / machine')
    parser.add_argument('--seed',
                        type=int,
                        default=30,
                        help='random seed')
    parser.add_argument('--sample-number',
                        type=int,
                        default=20,
                        help='random seed')
    parser.add_argument('--opt-level',
                        type=str,
                        default='O0',
                        help='optimization level for nvidia/apex')
    args = parser.parse_args()
    # number of GPUs totally, which equals to the number of processes
    args.world_size = args.nodes * args.gpus
    return args


def worker(rank_gpu, args):
    # create experiment output path if not exists
    if not os.path.exists(args.path):
        os.makedirs(args.path, exist_ok=True)

    # merge config with config file
    CFG.merge_from_file(args.config)

    assert CFG.EPOCHS % args.world_size == 0, 'cannot apportion epoch to gpus averagely'
    # log to file and stdout
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s: %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(args.path, 'test.log')),
            logging.StreamHandler(),
        ])

    # rank of global worker
    rank_process = args.gpus * args.rank_node + rank_gpu
    dist.init_process_group(backend=args.backend,
                            init_method=f'tcp://{args.master_ip}:{args.master_port}',
                            world_size=args.world_size,
                       rank=rank_process)
    # number of workers
    logging.info('train on {} of {} processes'.format(rank_process + 1, dist.get_world_size()))

    # use device cuda:n in the process #n
    torch.cuda.set_device(rank_gpu)
    device = torch.device('cuda', rank_gpu)

    # set random seed
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)


    # build dataset
    # train_dataset = build_dataset('train')
    # test_dataset = build_dataset('test')
    source_dataset = build_dataset('train')
    val_dataset = build_dataset('val')
    # assert train_dataset.num_classes == val_dataset.num_classes
    logging.info("Number of val {}".format(len(val_dataset)))
    NUM_CHANNELS = val_dataset.num_channels
    NUM_CLASSES = val_dataset.num_classes
    logging.info("Number of class: {}".format(NUM_CLASSES))
    # build data sampler
    # train_sampler = DistributedSampler(train_dataset, shuffle=True)
    # train_sampler = ImbalancedDatasetSampler(train_dataset, labels=train_dataset.get_labels())
    source_sampler = DistributedSampler(source_dataset, shuffle=False)
    val_sampler = DistributedSampler(val_dataset, shuffle=False)
    # test_sampler = DistributedSampler(test_dataset, shuffle=True)
    # test_sampler = ImbalancedDatasetSampler(test_dataset, labels=test_dataset.get_labels())
    print('GT:', type(val_dataset.get_labels()))
    print('shape of GT:', val_dataset.get_labels().shape)
    # build data loader
    # train_dataloader = build_dataloader(train_dataset, sampler=train_sampler)
    source_dataloader = build_dataloader(source_dataset, sampler=source_sampler)
    val_dataloader = build_dataloader(val_dataset, sampler=val_sampler)
    # test_dataloader = build_dataloader(test_dataset, sampler=test_sampler)

    val_criterion = build_criterion(CFG.CRITERION.ITEMS4, CFG.CRITERION.WEIGHTS4)
    val_criterion.to(device)

    # build model TODO: notice here
    G, D, C = build_model(NUM_CHANNELS, NUM_CLASSES)
    G.to(device)
    D.to(device)
    C.to(device)

    # DDP
    G = DistributedDataParallel(G)
    D = DistributedDataParallel(D)
    C = DistributedDataParallel(C)

    epoch = 0

    # load checkpoint if specified
    if args.checkpoint is not None:
        if not os.path.isfile(args.checkpoint):
            raise RuntimeError('checkpoint {} not found'.format(args.checkpoint))
        checkpoint = torch.load(args.checkpoint)
        G.load_state_dict(checkpoint['G']['state_dict'])
        D.load_state_dict(checkpoint['D']['state_dict'])
        C.load_state_dict(checkpoint['C']['state_dict'])
        # epoch = checkpoint['optimizer']['epoch']
        # iteration = checkpoint['optimizer']['iteration']
        best_OA = checkpoint['metric']['OA']
        # best_epoch = checkpoint['optimizer']['best_epoch']
        logging.info('load checkpoint {} with OA={:.4f}, epoch={}'.format(args.checkpoint, best_OA, epoch))

    # train - validation loop

    # validate
    G.eval()  # set model to evaluation mode
    D.eval()  # set model to evaluation mode
    C.eval()  # set model to evaluation mode
    # TODO attention:如果 retain graph = true 此处不能用eval() 否则计算图会被free掉 导致模型失效
    # metric.reset()  # reset metric

    val_loss = 0.
    features_s, features_t = [], []
    labels_s, labels_t = [], []
    with torch.no_grad():  # disable gradient back-propagation
        val_bar = tqdm(val_dataloader, desc='validating', ascii=True)
        for x_t, label, index in val_bar:
            x_t, label = x_t.to(device), label.to(device)
            f_t, y_t = C(x_t)

            loss = val_criterion(y_t, label)
            val_loss += loss.item()

            pred = y_t.argmax(axis=1)
            # print(f_t.data.cpu().numpy().shape)
            features_t.append(f_t.data.cpu().numpy())
            labels_t.append(label.data.cpu().numpy())
            val_dataset.update_pred(index.cpu(), pred.cpu())
            val_dataset.update_gtmap(index.cpu(), label.cpu())
            oa, aa, kappa, per_class_acc = get_criteria(pred.cpu().numpy(), label.cpu().numpy(), NUM_CLASSES)

            val_bar.set_postfix({
                'epoch': epoch,
                'loss': f'{loss.item():.4f}',
                'OA': f'{oa:.4f}',
                'AA': f'{aa:.4f}',
                'Kappa': f'{kappa:.4f}'
            })

        source_bar = tqdm(source_dataloader, desc='inferring-s', ascii=True)
        for x_s, label, index in source_bar:
            x_s, label = x_s.to(device), label.to(device)
            f_s, _ = C(x_s)
            # print(f_s.data.cpu().numpy().shape)
            features_s.append(f_s.data.cpu().numpy())
            labels_s.append(label.data.cpu().numpy())

    labels_s, labels_t = np.concatenate(labels_s), np.concatenate(labels_t)
    features_s, features_t = np.concatenate(features_s), np.concatenate(features_t)

    # plot
    pred_map = val_dataset.get_pred()    # [h,w]
    # gt_map = val_dataset.get_gtmap()
    plotter = plot_label(CFG.DATASET.NAME, NUM_CLASSES)
    img = plotter.plot_color(pred_map)
    ret_im = Image.fromarray(np.uint8(img)).convert('RGB')
    ret_im.save(os.path.join(args.path, 'CCGDA_new.tif'))
    # img = plotter.plot_color(gt_map)
    # ret_im = Image.fromarray(np.uint8(img)).convert('RGB')
    # ret_im.save(os.path.join(args.path, 'gt_source.tif'))
    # for i in range(NUM_CLASSES):
    iter_list = [705, 710, 715, 720, 725, 730]
    # iter_list = [300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950, 1000]
    for index in range(len(iter_list)):
        i = 3
        # print(np.array(features_t).shape)
        fs = features_s[np.where(labels_s == i)]
        ft = features_t[np.where(labels_t == i)]
        np.random.shuffle(fs)
        np.random.shuffle(ft)
        fs, ft = fs[:args.sample_number], ft[:args.sample_number]
        if len(fs) < args.sample_number:
            print("Not enough samples for class{} in source domain".format(i))
        if len(ft) < args.sample_number:
            print("Not enough samples for class{} in target domain".format(i))
        num_fs = len(fs)
        f = np.concatenate([fs, ft], axis=0)
        tsne = TSNE(n_components=2, perplexity=30, n_iter=iter_list[index], random_state=args.seed)
        f = tsne.fit_transform(f)
        # pca = PCA(n_components=2)
        # f = pca.fit_transform(f)
        fs, ft = f[:num_fs], f[num_fs:]
        # fs = tsne.fit_transform(fs)
        # ft = tsne.fit_transform(ft)
        plt.figure()
        plt.scatter(fs[:, 0], fs[:, 1], c='blue', s=3)
        plt.scatter(ft[:, 0], ft[:, 1], c='orange', s=3)
        plt.savefig(os.path.join(args.path, 'sep_feature{0}_tsne_class{1}.png'.format(iter_list[index], i)))



def main():
    # parse command line arguments
    args = parse_args()

    # multi processes, each process runs worker(i,args) i=range(nprocs)
    # total processes = world size = nprocs*nodes
    mp.spawn(worker, args=(args,), nprocs=args.gpus)


if __name__ == '__main__':
    main()
